// a simple hello-world program
// written by Xiao Lu

#include <stdio.h>

int main()
{
	char hello[] = "What's going on world! This is Xiao!";

	printf("%s\n", hello);

	return 0;

}