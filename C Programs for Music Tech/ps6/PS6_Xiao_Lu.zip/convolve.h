#ifndef _CONVOLVE_H_
#define _CONVOLVE_H_

int convolve(float *x, float *h, int lenX, int lenH, float *output);

#endif /* _CONVOLVE_H_ */
